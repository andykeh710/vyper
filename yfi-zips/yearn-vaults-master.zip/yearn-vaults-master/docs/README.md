# Docs have been migrated

This folder has been migrated to [yearn-devdocs](https://github.com/yearn/yearn-devdocs/tree/master/docs/v2)