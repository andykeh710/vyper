export const TOGGLE_DEV_MODE = 'app/DevMode/TOGGLE_DEV_MODE';
export const UNLOCK_DEV_MODE = 'app/DevMode/UNLOCK_DEV_MODE';
