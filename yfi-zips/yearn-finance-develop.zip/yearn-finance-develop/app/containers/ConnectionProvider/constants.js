/*
 *
 * Connection constants
 *
 */
export const CONNECTION_CONNECTED = 'CONNECTION_CONNECTED';
export const ACCOUNT_UPDATED = 'ACCOUNT_UPDATED';
