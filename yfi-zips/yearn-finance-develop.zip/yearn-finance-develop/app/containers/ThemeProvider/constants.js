/*
 *
 * Theme constants
 *
 */
export const TOGGLE_DARK_MODE = 'app/ThemeToggle/TOGGLE_DARK_MODE';
export const SET_THEME_MODE = 'app/ThemeToggle/SET_MODE';

export const DARK_MODE = 'DARK_MODE';
export const LIGHT_MODE = 'LIGHT_MODE';
