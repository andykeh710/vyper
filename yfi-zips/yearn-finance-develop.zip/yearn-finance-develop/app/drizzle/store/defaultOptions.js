const defaultOptions = {
  web3: {
    // `block` no longer needed;
    // keeping for pre-v1.1.1 compatibility with drizzle-react.
    block: false,
    fallback: {
      type: 'ws',
      url: 'ws://127.0.0.1:8545',
    },
  },
  contracts: [],
  events: {},
  polls: {
    blocks: 3000,
  },
  syncAlways: false,
  networkWhitelist: [],
};

export default defaultOptions;
