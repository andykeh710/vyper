export const EVENT_FIRED = 'EVENT_FIRED';
export const EVENT_CHANGED = 'EVENT_CHANGED';
export const EVENT_ERROR = 'EVENT_ERROR';
