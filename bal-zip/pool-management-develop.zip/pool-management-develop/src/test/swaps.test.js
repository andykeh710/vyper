test('network sanity check', async () => {
    expect(42).toEqual(42);
});
