import { LiquidityPage } from '.';

export default {
  path: 'liquidity',
  childRoutes: [
    { path: 'index', component: LiquidityPage, isIndex: true },
  ],
};
