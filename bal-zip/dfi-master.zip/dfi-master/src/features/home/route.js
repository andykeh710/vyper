import { HomePage } from './';

export default {
  path: '',
  childRoutes: [
    { path: 'index', component: HomePage, isIndex: true },
  ],
};
