import { ZapPage } from '.';

export default {
  path: 'zap',
  childRoutes: [
    { path: 'zap', component: ZapPage, isIndex: true },
  ],
};
