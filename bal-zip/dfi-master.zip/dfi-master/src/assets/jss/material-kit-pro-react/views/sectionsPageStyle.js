import { main } from "assets/jss/material-kit-pro-react.js";

const sectionsPageStyle = {
  main: {
    ...main
  }
};

export default sectionsPageStyle;
