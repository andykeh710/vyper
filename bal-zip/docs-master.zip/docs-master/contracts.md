?> _TODO_ Guide for developers

https://github.com/yfii