?> TODO: 中文文档正在完善整合中，请暂时参考以下教程

## 资料汇总

https://www.yuque.com/sawd49/yfii-cn

## 常用教程

项目介绍与Pool 1挖矿教程： https://docs.qq.com/doc/DUnVXcFh3a0JwdGdN

Pool2挖矿与YFII交易教程： https://docs.qq.com/doc/DUnJVU0NXYUhPZVlC

Uniswap YFII-ETH流动性做市教程： https://docs.qq.com/doc/DUlFVRWpOd25aVW1q

YFII 机枪池的使用方法请见：https://docs.qq.com/doc/DUlpka0FXeGVMbkhm

YFII - Curve策略挖矿手册： https://docs.qq.com/doc/DUnBNY0VLSm9QaG9h