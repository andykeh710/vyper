# StrategyYfiiPool2

接受bpt来挖 yfii

yvault内置了 dai2bpt,bpt2dai 来方便转换